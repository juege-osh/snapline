import AppKit
let image = NSImage(size: NSSize(width: 512, height: 512))
image.lockFocus()
NSColor.systemIndigo.setFill()
NSBezierPath(roundedRect: NSRect(x: 0, y: 0, width: 512, height: 512), xRadius: 100, yRadius: 100).fill()
NSImage(systemSymbolName: "photo.stack", accessibilityDescription: nil)!.draw(in: NSRect(x: 96, y: 96, width: 320, height: 320))
image.unlockFocus()
try image.tiffRepresentation!.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
